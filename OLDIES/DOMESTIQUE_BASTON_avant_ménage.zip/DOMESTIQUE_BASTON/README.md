# DOMESTIQUE_BASTON
A free/open source/whatever VS Fighting game...

DOMESTIQUE BASTON is a VERSUS FIGHTING GAME intended to be a quite simple VS Fighting game for casual gamers... No complicated quart circle forward + A/B or stuff like that.

In order to limit the amount of work for that project, we thought that the idea of a couple fighting would be an excellent reason for us to have only two playable characters (and we certainly don't care about political correctness).

It's planned to be released as a free/open source project by good willing people! At this point of development, we still don't know under what kind of license it'll be distributed but for very sure a non commercial one.

Depending on the time and energy we have when "v1.0" is released, we'll eventually add features to that game but, and that's the point of the open source thing, don't wait for us and feel free to add whatever you want to that game. We'd be thrilled to see what you'd come up with...

The team
